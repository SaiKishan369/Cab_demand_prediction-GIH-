from flask import Flask, request, jsonify, send_from_directory
import joblib
import numpy as np
from datetime import datetime
import os

app = Flask(__name__)

# Load the trained model
model_path = os.path.join("models", "demand_prediction_model.pkl")
model = joblib.load(model_path)

@app.route("/")
def home():
    return send_from_directory("static", "index.html")  # Serve index.html properly

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    latitude = float(data["latitude"])
    longitude = float(data["longitude"])
    time_str = data["time"]

    # Convert time to numerical format (minutes since midnight)
    time_obj = datetime.strptime(time_str, "%H:%M")
    time_numeric = time_obj.hour * 60 + time_obj.minute

    # Prepare input for model
    input_features = np.array([[latitude, longitude, time_numeric]])
    prediction = model.predict(input_features)

    # Convert prediction result
    demand_status = "High" if prediction[0] == 1 else "Low"

    return jsonify({"demand": demand_status})

if __name__ == "__main__":
    app.run(debug=True)
