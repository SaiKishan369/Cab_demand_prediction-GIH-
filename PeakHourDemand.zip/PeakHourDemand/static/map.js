function initMap() {
    const bangalore = { lat: 12.9716, lng: 77.5946 };
    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 12,
        center: bangalore,
    });

    // Load the BBMP GeoJSON file
    map.data.loadGeoJson("BBMP.geojson");

    // Define colors
    const defaultColor = "rgba(173, 216, 230, 0.3)"; // Light blue with low opacity
    const specialColor = "#0000FF"; // Blue for kgiswardno = 1

    // Set styles for the GeoJSON data
    map.data.setStyle(feature => {
        const kgiswardno = feature.getProperty("kgiswardno");
        return {
            fillColor: kgiswardno === 1 ? specialColor : defaultColor, // Blue for ward 1, light blue for others
            fillOpacity: 0.3, // Low opacity
            strokeColor: "#4A4A4A", // Dark grey border
            strokeWeight: 1.5, // Border thickness
        };
    });

    // Add toggle functionality
    const toggleWards = document.getElementById("toggle-wards");
    toggleWards.addEventListener("change", () => {
        if (toggleWards.checked) {
            map.data.setStyle(feature => {
                const kgiswardno = feature.getProperty("kgiswardno");
                return {
                    fillColor: kgiswardno === 1 ? specialColor : defaultColor,
                    fillOpacity: 0.3,
                    strokeColor: "#4A4A4A",
                    strokeWeight: 1.5,
                };
            });
        } else {
            map.data.setStyle({
                visible: false, // Hide all wards
            });
        }
    });
}
function initMap() {
    const bangalore = { lat: 12.9716, lng: 77.5946 };
    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 12,
        center: bangalore,
    });

    // Enable Real-Time Traffic Layer
    const trafficLayer = new google.maps.TrafficLayer();
    trafficLayer.setMap(map);

    // Load BBMP Wards GeoJSON
    map.data.loadGeoJson("BBMP.geojson");

    // Define ward styles
    function applyWardStyles(visible) {
        map.data.setStyle(feature => {
            if (!visible) return { visible: false };
            return {
                fillColor: "rgba(173, 216, 230, 0.3)", // Light blue
                fillOpacity: 0.3,
                strokeColor: "#4A4A4A",
                strokeWeight: 1.5,
            };
        });
    }
    applyWardStyles(true); // Show wards initially

    // Toggle Wards
    document.getElementById("toggle-wards").addEventListener("change", (event) => {
        applyWardStyles(event.target.checked);
    });

    // Toggle Traffic
    document.getElementById("toggle-traffic").addEventListener("change", (event) => {
        trafficLayer.setMap(event.target.checked ? map : null);
    });

    // Auto-refresh traffic every 2 minutes
    setInterval(() => {
        if (document.getElementById("toggle-traffic").checked) {
            trafficLayer.setMap(null);
            const newTrafficLayer = new google.maps.TrafficLayer();
            newTrafficLayer.setMap(map);
        }
    }, 120000);

    // ✅ Load Metro Locations and Add Purple Dots
    fetch("metro_locations.json")
        .then(response => response.json())
        .then(metroStations => {
            metroStations.forEach(station => {
                const marker = new google.maps.Marker({
                    position: { lat: station.Latitude, lng: station.Longitude },
                    map: map,
                    icon: {
                        path: google.maps.SymbolPath.CIRCLE,
                        scale: 6,
                        fillColor: "purple",
                        fillOpacity: 1,
                        strokeWeight: 0
                    },
                    title: station.Name
                });

                // Show metro station name on hover
                const infoWindow = new google.maps.InfoWindow({
                    content: `<b>${station.Name}</b>`
                });

                marker.addListener("mouseover", () => infoWindow.open(map, marker));
                marker.addListener("mouseout", () => infoWindow.close());
            });
        })
        .catch(error => console.error("Error loading metro locations:", error));
}


// Function to handle button click

